"use strict";
const root=document.querySelector('#app');
async function api(operation,data={}){
  const dialog=document.querySelector('tk-dialog[open]'),form=dialog?.querySelector('form'),actor=session?.account.id,generation=loadGeneration;
  const response=await fetch('/api/tools/'+operation,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}),result=await response.json();
  if(!response.ok){const error=new Error(result.error?.message||'Request failed');error.status=response.status;error.code=result.error?.code;throw error;}
  const personal=['setAppearance','saveViewPreferences','saveCurrentLocation','getViewPreferences','attachSession','listSessions','getLocalHarnesses','getScriptBindings','getScriptRun','listScriptRuns'].includes(operation);
  if(!['getSession','login'].includes(operation)&&(!personal&&generation!==loadGeneration||actor&&session?.account.id!==actor)){const error=new Error('Request completed after its account or view changed');error.staleInteraction=true;throw error;}
  if(form&&!personal&&!/^(get|list|preview|search)/.test(operation)&&(!dialog.open||dialog.querySelector('form')!==form||session?.account.id!==actor||generation!==loadGeneration)){const error=new Error('Request completed after its interaction changed');error.staleInteraction=true;throw error;}
  return result;
}
let noticeTimer;function notice(message){clearTimeout(noticeTimer);document.querySelector('#notice').textContent=message;if(message)noticeTimer=setTimeout(()=>{document.querySelector('#notice').textContent='';},5000);}
function login(){loadGeneration++;detailEpoch++;clearPresentation();session=null;projects=[];tickets=[];ideas=[];root.innerHTML='<section class="login">'+landingBrand()+'<form id="login"><label>Username<input name="username" autocomplete="username" required autofocus></label><label>Password<input name="password" type="password" autocomplete="current-password" required></label><button>Sign in</button></form></section>';root.querySelector('input').focus();if(typeof startLandingFlight==='function')startLandingFlight().catch(()=>{});root.querySelector('form').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget;const button=form.querySelector('button');button.disabled=true;try{await api('login',Object.fromEntries(new FormData(form)));notice('');await start();}catch(error){notice(error.message);}finally{button.disabled=false;}};}
async function start(){try{await workspace();}catch(error){if(error.status===401||error.status===403)login();else{connectionInitialRetry=true;showConnectionInterrupted();probeConnection();}}}
start();
